package com.example.sasistencia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class TomarAsistenciaActivity extends AppCompatActivity {

    private RecyclerView recyclerAlumnos;
    ArrayList<Alumno>  listaDeAlumnos = new ArrayList<>();
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    DatabaseReference mRootRef;
    DatabaseReference mGradosRef;
    DatabaseReference mPrimeroBasicoRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tomar_asistencia);
        recyclerAlumnos = findViewById(R.id.lista_alumnos);
        recyclerAlumnos.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerAlumnos.setLayoutManager(layoutManager);

        mRootRef = FirebaseDatabase.getInstance().getReference();
        mGradosRef = mRootRef.child("grados");
        mPrimeroBasicoRef = mGradosRef.child("PrimeroBasico");
        mPrimeroBasicoRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                    Alumno alumno = dataSnapshot1.getValue(Alumno.class);
                    listaDeAlumnos.add(alumno);

                }
                mAdapter = new ListaAlumnosAdapter(listaDeAlumnos,TomarAsistenciaActivity.this);
                recyclerAlumnos.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        recyclerAlumnos.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }


}
