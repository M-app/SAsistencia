package com.example.sasistencia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    Spinner spinner_carreras, spinner_grados;
    Button btnListo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner_carreras = (Spinner) findViewById(R.id.spinner_carreras);
        spinner_grados = (Spinner) findViewById(R.id.spinner_grados);
        btnListo = (Button) findViewById(R.id.btn_listo);
        configSecondSpinner();
        btnListo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirListaAlumnosActivity();
            }
        });
    }

    private void abrirListaAlumnosActivity() {
        Intent intent = new Intent(this,TomarAsistenciaActivity.class);
        startActivity(intent);
    }

    private void configSecondSpinner(){
        spinner_carreras.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String carrera = spinner_carreras.getSelectedItem().toString();
                if (carrera.equals("Básico")){
                    spinner_grados.setAdapter(getBasicosAdapter());
                }else if(carrera.equals("Bachillerato")){
                    spinner_grados.setAdapter(getBachilleratosAdapter());
                }else if(carrera.equals("Magisterio")){
                    spinner_grados.setAdapter(getMagisteriosAdapter());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private ArrayAdapter<CharSequence> getBasicosAdapter(){
        return ArrayAdapter.createFromResource(this,
                R.array.lista_basicos,
                android.R.layout.simple_spinner_dropdown_item);
    }

    private ArrayAdapter<CharSequence> getBachilleratosAdapter(){
        return ArrayAdapter.createFromResource(this,
                                                        R.array.lista_bachilleratos,
                                                        android.R.layout.simple_spinner_dropdown_item);
    }

    private ArrayAdapter<CharSequence> getMagisteriosAdapter(){
        return ArrayAdapter.createFromResource(this,
                R.array.lista_magisterios,
                android.R.layout.simple_spinner_dropdown_item);
    }
}
