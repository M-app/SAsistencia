package com.example.sasistencia;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Map;

public class DatosAlumnos {
    DatabaseReference mRootRef;
    DatabaseReference mGradosRef;
    DatabaseReference mPrimeroBasicoRef;
    private Object alumno;

    private ArrayList<Alumno> mListaAlumnos = new ArrayList<>();

    public DatosAlumnos() {
        mRootRef = FirebaseDatabase.getInstance().getReference();
        mGradosRef = mRootRef.child("grados");
        mPrimeroBasicoRef = mGradosRef.child("PrimeroBasico");
        mPrimeroBasicoRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                setDatosAlumnos((Map<String,Alumno>) dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void setDatosAlumnos(Map<String,Alumno> alumnos){
        for(Map.Entry<String,Alumno> entrada : alumnos.entrySet()){
            Alumno alumno =  entrada.getValue();
            mListaAlumnos.add(alumno);
        }
    }

    public ArrayList<Alumno> getDatosAlumnos(){
        return mListaAlumnos;
    }

}
