package com.example.sasistencia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListaAlumnosAdapter extends RecyclerView.Adapter<ListaAlumnosAdapter.ViewHolder> {

    private ArrayList<Alumno> listaAlumnos;
    private Context mContext;

    public ListaAlumnosAdapter(ArrayList<Alumno> listaAlumnos, Context mContext) {
        this.listaAlumnos = listaAlumnos;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.item_estudiante,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Alumno alumno = listaAlumnos.get(position);
        holder.txtClave.setText(alumno.getClave());
        holder.txtApellidos.setText(alumno.getApellidos());
        holder.txtNombres.setText(alumno.getNombres());
        holder.checkAsistencia.setChecked(alumno.getAsistencia() ==1);
    }

    @Override
    public int getItemCount() {
        return listaAlumnos == null ? 0 : listaAlumnos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtClave;
        TextView txtApellidos;
        TextView txtNombres;
        CheckBox checkAsistencia;
        LinearLayout item_nombre_alumno;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtClave = itemView.findViewById(R.id.txt_clave);
            txtApellidos = itemView.findViewById(R.id.txt_apellidos);
            txtNombres = itemView.findViewById(R.id.txt_nombres);
            checkAsistencia = itemView.findViewById(R.id.check_asistencia);
            item_nombre_alumno =  itemView.findViewById(R.id.item_nombre_alumno);
        }
        // each data item is just a string in this case

    }

}
