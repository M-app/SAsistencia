package com.example.sasistencia;

public class Alumno {
    private String clave;
    private String apellidos;
    private String nombres;
    // 0 si el alumno se ausentó y 1 si el alumno si asistió
    private Integer asistencia;

    public Alumno(){}

    public Alumno(String clave, String apellidos, String nombres, Integer asistencia) {
        this.clave = clave;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.asistencia = asistencia;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public Integer getAsistencia(){
        return asistencia;
    }

    public void setAsistencia(Integer asistencia){
        this.asistencia = asistencia;
    }
}
